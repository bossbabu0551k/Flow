package io.github.aedev.flow.ui.components.videoplayer.ambient

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp

/**
 * Where the video surface hands its latest blurred frame to the watch page, so the page can draw it
 * under the *whole* screen instead of only around the video.
 */
@Stable
class AmbientScreenState {
    /** Latest blurred frame; kept after ambient stops so the backdrop can fade out instead of popping. */
    var frame: ImageBitmap? by mutableStateOf(null)
        private set

    /** True while a non-fullscreen video is feeding frames. */
    var active: Boolean by mutableStateOf(false)

    /** True when the backdrop is on screen, so the page above it must stop painting its own ground. */
    val visible: Boolean get() = active && frame != null

    fun publish(next: ImageBitmap?) {
        if (next != null) frame = next
    }
}

/**
 * There is only ever one watch page, so the writer (the video surface) and the readers (the sheet
 * and the page body) share one process-wide instance. Nothing has to be provided in the composition,
 * so the hand-off cannot be lost to composition-tree structure.
 */
object AmbientScreen {
    val state = AmbientScreenState()
}

val LocalAmbientScreenState = staticCompositionLocalOf { AmbientScreen.state }

private const val SCRIM_TOP = 0.30f
private const val SCRIM_BOTTOM = 0.62f

/**
 * Whole-screen ambient: a heavily blurred copy of the playing video, behind every UI element.
 *
 * The frame is stretched to the screen so each part of the screen takes the colours of the matching
 * part of the video; with the blur that reads as the video's light spilling over the page. A dark
 * scrim, deeper towards the bottom where the text-heavy page sits, keeps titles, comments and icons
 * readable whatever the video shows.
 *
 * [alpha] carries the sheet's expand/collapse fade and is read while drawing.
 */
@Composable
fun AmbientScreenBackdrop(
    state: AmbientScreenState,
    alpha: () -> Float,
    modifier: Modifier = Modifier,
) {
    val presence by animateFloatAsState(
        targetValue = if (state.visible) 1f else 0f,
        animationSpec = tween(500),
        label = "ambientScreenPresence",
    )
    val frame = state.frame
    if (frame == null || presence <= 0.001f) return

    Box(
        modifier =
            modifier
                .fillMaxSize()
                .graphicsLayer { this.alpha = presence * alpha() }
                .drawBehind { drawRect(Color.Black) },
    ) {
        Image(
            bitmap = frame,
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            filterQuality = FilterQuality.Medium,
            // Gaussian blur on Android 12+. Older Android has no GPU blur, so it shows the same
            // frame bilinear-smoothed; the colour grid is already very soft.
            modifier = Modifier.fillMaxSize().blur(36.dp),
        )
        Box(
            modifier =
                Modifier.fillMaxSize().drawBehind {
                    drawRect(
                        Brush.verticalGradient(
                            0f to Color.Black.copy(alpha = SCRIM_TOP),
                            1f to Color.Black.copy(alpha = SCRIM_BOTTOM),
                        ),
                    )
                },
        )
    }
}
