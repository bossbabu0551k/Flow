package io.github.aedev.flow.ui.glass

import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material3.DropdownMenuGroup
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenuPopup
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.coerceAtMost
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.fastCoerceIn
import androidx.compose.ui.util.lerp
import com.kyant.backdrop.backdrops.LayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.colorControls
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.backdrop.highlight.Highlight
import com.kyant.backdrop.shadow.InnerShadow
import com.kyant.backdrop.shadow.Shadow
import io.github.aedev.flow.R
import io.github.aedev.flow.ui.components.layout.navigation.FlowTab
import io.github.aedev.flow.ui.components.layout.navigation.icon
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.drop
import kotlin.math.roundToInt
import kotlin.math.sign

private val CapsuleShape = RoundedCornerShape(percent = 50)
private val MaxTabWidth = 96.dp
private val BarHeight = 64.dp
private val BlobHeight = 56.dp

// Breathing room between the capsule edge and the pill on the first/last tab.
private val BarInset = 6.dp
private val BarSideMargin = 16.dp
private val BarBottomMargin = 8.dp
private const val MAX_BAR_TABS = 5

/**
 * Flow's bottom bar, in SimpMusic's liquid-glass style: a floating glass capsule with a glass blob
 * that slides to the selected tab, stretches with drag speed, and bulges out of the bar when pressed.
 *
 * - Android 13+  : liquid glass (blur, refracting lens, vibrancy, rim light, shadows).
 * - Android 12/L : real-time backdrop blur; same shapes and the same animation, no lens.
 * - Android 11-  : frosted translucent capsule; same shapes and the same animation.
 *
 * [onHeightChanged] reports the height the bar takes above the system navigation inset, so screens
 * can keep their content clear of it.
 */
@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
internal fun FlowGlassBottomBar(
    tabs: List<FlowTab>,
    selectedTab: FlowTab?,
    onTabSelected: (FlowTab) -> Unit,
    backdrop: LayerBackdrop,
    modifier: Modifier = Modifier,
    onHeightChanged: (Dp) -> Unit = {},
) {
    val density = LocalDensity.current
    val navInsetPx = WindowInsets.navigationBars.getBottom(density)
    val barTabs = if (tabs.size <= MAX_BAR_TABS) tabs else tabs.take(MAX_BAR_TABS - 1)
    val overflowTabs = tabs.drop(barTabs.size)
    // null stands for the "More" slot.
    val entries: List<FlowTab?> = if (overflowTabs.isEmpty()) barTabs else barTabs + listOf<FlowTab?>(null)
    val selectedIndex =
        when {
            selectedTab == null -> 0
            selectedTab in barTabs -> barTabs.indexOf(selectedTab)
            overflowTabs.isNotEmpty() && selectedTab in overflowTabs -> entries.lastIndex
            else -> 0
        }

    BoxWithConstraints(
        modifier =
            modifier
                .fillMaxWidth()
                .onSizeChanged { size ->
                    onHeightChanged(with(density) { (size.height - navInsetPx).coerceAtLeast(0).toDp() })
                }.windowInsetsPadding(WindowInsets.navigationBars)
                .padding(bottom = BarBottomMargin),
        contentAlignment = Alignment.BottomCenter,
    ) {
        FlowGlassTabBar(
            entries = entries,
            selectedIndex = selectedIndex,
            overflowTabs = overflowTabs,
            selectedTab = selectedTab,
            backdrop = backdrop,
            availableWidth = maxWidth - BarSideMargin * 2,
            onEntrySelected = { position ->
                val tab = entries.getOrNull(position)
                if (tab != null) onTabSelected(tab)
            },
            onOverflowSelected = onTabSelected,
        )
    }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun FlowGlassTabBar(
    entries: List<FlowTab?>,
    selectedIndex: Int,
    overflowTabs: List<FlowTab>,
    selectedTab: FlowTab?,
    backdrop: LayerBackdrop,
    availableWidth: Dp,
    onEntrySelected: (Int) -> Unit,
    onOverflowSelected: (FlowTab) -> Unit,
) {
    val density = LocalDensity.current
    val tabsCount = entries.size
    val tabWidth = ((availableWidth - BarInset * 2) / tabsCount).coerceAtMost(MaxTabWidth)
    val fullWidth = tabWidth * tabsCount + BarInset * 2
    val tabWidthPx = with(density) { tabWidth.toPx() }
    val currentTabWidthPx by rememberUpdatedState(tabWidthPx)
    val isLtr = LocalLayoutDirection.current == LayoutDirection.Ltr
    val animationScope = rememberCoroutineScope()
    val barInteraction = rememberGlassInteraction()
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val tier = FlowGlass.tier

    // Records what is behind the capsule so the glass can adapt its darkness to it.
    val layer = rememberGraphicsLayer()
    val luminance = rememberGlassLuminance(layer, enabled = tier != GlassTier.FROSTED)

    var currentIndex by remember { mutableIntStateOf(selectedIndex.coerceAtLeast(0)) }
    // A real drag happened (as opposed to a tap): keeps the blob from stealing a tab tap.
    val draggedFlag = remember { booleanArrayOf(false) }
    var moreOpen by remember { mutableStateOf(false) }

    val dampedDrag =
        remember(animationScope, tabsCount) {
            DampedDragAnimation(
                animationScope = animationScope,
                initialValue = selectedIndex.coerceAtLeast(0).toFloat(),
                valueRange = 0f..(tabsCount - 1).toFloat().coerceAtLeast(0f),
                visibilityThreshold = 0.001f,
                initialScale = 1f,
                // On press the blob inflates from 56dp to ~76dp, past the 64dp bar, so it visibly
                // bulges out of the capsule (Apple Music style), then springs back on release.
                pressedScale = 76f / 56f,
                onDragStarted = { draggedFlag[0] = false },
                onDragStopped = {
                    if (draggedFlag[0]) {
                        val target = targetValue.roundToInt().coerceIn(0, tabsCount - 1)
                        currentIndex = target
                        // Always snap to a tab, or the blob can stop mid-slide after release.
                        animateToValue(target.toFloat())
                    }
                },
                onDrag = { _, dragAmount ->
                    if (dragAmount.x != 0f) draggedFlag[0] = true
                    updateValue(
                        (targetValue + dragAmount.x / currentTabWidthPx * if (isLtr) 1f else -1f)
                            .coerceIn(0f, (tabsCount - 1).toFloat()),
                    )
                },
            )
        }

    // Keep the blob in sync when the selection changes from outside (back stack, deep links).
    LaunchedEffect(selectedIndex) {
        if (selectedIndex >= 0 && currentIndex != selectedIndex) currentIndex = selectedIndex
    }
    // Slide the blob whenever the internal index changes; only a drag-snap navigates from here.
    LaunchedEffect(dampedDrag) {
        snapshotFlow { currentIndex }
            .drop(1)
            .collectLatest { index ->
                dampedDrag.animateToValue(index.toFloat())
                val navigate = draggedFlag[0]
                draggedFlag[0] = false
                if (navigate) onEntrySelected(index)
            }
    }

    Box(
        modifier =
            Modifier
                .height(BarHeight)
                .width(fullWidth)
                // The whole capsule reacts to a press; this outer box sees the touch first.
                .pointerInput(barInteraction) { barInteraction.detectPress(this) },
        contentAlignment = Alignment.CenterStart,
    ) {
        // 1) The glass capsule.
        Box(
            Modifier
                .matchParentSize()
                .drawInteractiveGlass(isDark, backdrop, layer, { luminance.value }, CapsuleShape, barInteraction),
        )

        // The blob and tabs keep a fixed full-width layout; nothing clips them, so the pressed blob
        // can bulge out of the capsule.
        Box(Modifier.matchParentSize()) {
            Box(
                Modifier
                    .wrapContentSize(Alignment.CenterStart, unbounded = true)
                    .size(fullWidth, BarHeight),
                contentAlignment = Alignment.CenterStart,
            ) {
                // 2) The sliding glass blob (selection indicator), behind the icons.
                Box(
                    Modifier
                        .drawGlassBlob(
                            isDark = isDark,
                            backdrop = backdrop,
                            luminance = { luminance.value },
                            drag = dampedDrag,
                            offsetX = {
                                (if (isLtr) dampedDrag.value else (tabsCount - 1) - dampedDrag.value) * tabWidthPx +
                                    with(density) { BarInset.toPx() }
                            },
                        ).width(tabWidth)
                        .height(BlobHeight),
                )

                // 3) Crisp icons and labels on top, carrying the drag gesture.
                Row(
                    Modifier
                        .matchParentSize()
                        .padding(horizontal = BarInset)
                        .then(dampedDrag.modifier),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    entries.forEachIndexed { position, tab ->
                        GlassTab(
                            tab = tab,
                            selected = currentIndex == position,
                            width = tabWidth,
                            menu =
                                if (tab == null) {
                                    {
                                        OverflowMenu(
                                            expanded = moreOpen,
                                            tabs = overflowTabs,
                                            selectedTab = selectedTab,
                                            onDismiss = { moreOpen = false },
                                            onSelected = {
                                                moreOpen = false
                                                onOverflowSelected(it)
                                            },
                                        )
                                    }
                                } else {
                                    null
                                },
                        ) {
                            if (tab == null) {
                                // "More" only opens its menu; the blob stays on the current tab.
                                moreOpen = true
                            } else if (position == currentIndex) {
                                // Re-tapping the active tab: the index does not change, so call
                                // through directly to keep scroll-to-top / reload behaviour.
                                onEntrySelected(position)
                            } else {
                                // Navigate on tap directly; routing through the snapshot flow can
                                // drop the tap when a drag-stop races it.
                                currentIndex = position
                                onEntrySelected(position)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GlassTab(
    tab: FlowTab?,
    selected: Boolean,
    width: Dp,
    menu: (@Composable () -> Unit)?,
    onClick: () -> Unit,
) {
    val color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
    Box(Modifier.width(width).fillMaxHeight()) {
        Column(
            Modifier
                .width(width)
                .fillMaxHeight()
                .clip(CapsuleShape)
                .clickable(
                    interactionSource = null,
                    indication = null,
                    role = Role.Tab,
                    onClick = onClick,
                ),
            verticalArrangement = Arrangement.spacedBy(2.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            CompositionLocalProvider(LocalContentColor provides color) {
                Icon(
                    imageVector = if (tab != null) tab.icon(selected) else Icons.Filled.MoreHoriz,
                    contentDescription = null,
                    tint = color,
                )
                Text(
                    text = stringResource(tab?.labelRes ?: R.string.nav_more),
                    style = MaterialTheme.typography.labelSmall,
                    color = color,
                    maxLines = 1,
                )
            }
        }
        menu?.invoke()
    }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun OverflowMenu(
    expanded: Boolean,
    tabs: List<FlowTab>,
    selectedTab: FlowTab?,
    onDismiss: () -> Unit,
    onSelected: (FlowTab) -> Unit,
) {
    DropdownMenuPopup(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuGroup(shapes = MenuDefaults.groupShape(index = 0, count = 1)) {
            tabs.forEachIndexed { index, tab ->
                DropdownMenuItem(
                    selected = tab == selectedTab,
                    onClick = { onSelected(tab) },
                    text = { Text(text = stringResource(tab.labelRes)) },
                    shapes = MenuDefaults.itemShape(index = index, count = tabs.size),
                    leadingIcon = {
                        Icon(
                            imageVector = tab.icon(selected = false),
                            contentDescription = null,
                            modifier = Modifier.size(MenuDefaults.LeadingIconSize),
                        )
                    },
                    selectedLeadingIcon = {
                        Icon(
                            imageVector = tab.icon(selected = true),
                            contentDescription = null,
                            modifier = Modifier.size(MenuDefaults.LeadingIconSize),
                        )
                    },
                )
            }
        }
    }
}

/** The glass behind the capsule, by device tier. [interaction] adds the press scale and touch glow. */
private fun Modifier.drawInteractiveGlass(
    isDark: Boolean,
    backdrop: LayerBackdrop,
    layer: GraphicsLayer?,
    luminance: () -> Float,
    shape: Shape,
    interaction: GlassInteraction?,
    pressedScale: Float = 1.12f,
): Modifier =
    when (FlowGlass.tier) {
        GlassTier.LIQUID ->
            this
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { shape },
                    highlight = { Highlight.Default },
                    effects = {
                        val l = (luminance() * 2f - 1f).let { sign(it) * it * it }
                        val press = interaction?.pressProgress ?: 0f
                        vibrancy()
                        colorControls(
                            brightness = 0.05f,
                            contrast = 1f,
                            saturation = 1.5f,
                        )
                        blur(
                            (
                                if (l > 0f) {
                                    lerp(8f.dp.toPx(), 16f.dp.toPx(), l)
                                } else {
                                    lerp(8f.dp.toPx(), 2f.dp.toPx(), -l)
                                }
                            ) + 2f.dp.toPx() * press,
                        )
                        lens(size.minDimension / 4f + 2f.dp.toPx() * press, size.minDimension / 2f, false)
                    },
                    onDrawBackdrop = { drawBackdrop ->
                        drawBackdrop()
                        layer?.record { drawBackdrop() }
                    },
                    onDrawSurface = { drawGlassSurface(isDark, luminance(), interaction) },
                    layerBlock =
                        if (interaction != null) {
                            {
                                val scale = lerp(1f, pressedScale, interaction.pressProgress)
                                scaleX = scale
                                scaleY = scale
                            }
                        } else {
                            null
                        },
                ).then(pressModifier(interaction))

        GlassTier.BLUR ->
            this
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { shape },
                    effects = {
                        val l = (luminance() * 2f - 1f).let { sign(it) * it * it }
                        val press = interaction?.pressProgress ?: 0f
                        colorControls(
                            brightness = 0.05f,
                            contrast = 1f,
                            saturation = 1.4f,
                        )
                        blur(
                            (
                                if (l > 0f) {
                                    lerp(10f.dp.toPx(), 18f.dp.toPx(), l)
                                } else {
                                    lerp(10f.dp.toPx(), 4f.dp.toPx(), -l)
                                }
                            ) + 2f.dp.toPx() * press,
                        )
                    },
                    onDrawBackdrop = { drawBackdrop ->
                        drawBackdrop()
                        layer?.record { drawBackdrop() }
                    },
                    onDrawSurface = { drawGlassSurface(isDark, luminance(), interaction) },
                    layerBlock =
                        if (interaction != null) {
                            {
                                val scale = lerp(1f, pressedScale, interaction.pressProgress)
                                scaleX = scale
                                scaleY = scale
                            }
                        } else {
                            null
                        },
                ).then(pressModifier(interaction))

        GlassTier.FROSTED ->
            this
                .graphicsLayer {
                    val scale = lerp(1f, pressedScale, interaction?.pressProgress ?: 0f)
                    scaleX = scale
                    scaleY = scale
                }.background(frostedFill(isDark), shape)
                .border(0.75.dp, frostedEdge(isDark), shape)
                .then(pressModifier(interaction))
    }

private fun pressModifier(interaction: GlassInteraction?): Modifier =
    if (interaction != null) Modifier.pointerInput(interaction) { interaction.detectPress(this) } else Modifier

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawGlassSurface(
    isDark: Boolean,
    luminance: Float,
    interaction: GlassInteraction?,
) {
    // Darker over bright content, so the glass never washes out to white.
    val darken = lerp(0.12f, 0.5f, ((luminance - 0.3f) / 0.5f).coerceIn(0f, 1f))
    drawRect((if (isDark) Color.Black else Color.White).copy(alpha = darken))
    val press = interaction?.pressProgress ?: 0f
    if (press > 0f) {
        drawRect(
            brush =
                Brush.radialGradient(
                    colors = listOf(Color.White.copy(alpha = 0.18f * press), Color.Transparent),
                    center = interaction?.touchPosition ?: Offset(size.width / 2f, size.height / 2f),
                    radius = size.minDimension * 1.2f,
                ),
            blendMode = BlendMode.Plus,
        )
    }
}

/** The sliding selection blob, by device tier. Squashes and stretches with drag velocity. */
private fun Modifier.drawGlassBlob(
    isDark: Boolean,
    backdrop: LayerBackdrop,
    luminance: () -> Float,
    drag: DampedDragAnimation,
    offsetX: () -> Float,
): Modifier =
    when (FlowGlass.tier) {
        GlassTier.LIQUID ->
            this
                .graphicsLayer { translationX = offsetX() }
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { CapsuleShape },
                    effects = {
                        val l = (luminance() * 2f - 1f).let { sign(it) * it * it }
                        val progress = drag.pressProgress
                        vibrancy()
                        colorControls(
                            brightness = 0.05f,
                            contrast = 1f,
                            saturation = 1.5f,
                        )
                        blur(
                            (if (l > 0f) lerp(8f.dp.toPx(), 16f.dp.toPx(), l) else lerp(8f.dp.toPx(), 2f.dp.toPx(), -l)) +
                                20f.dp.toPx(),
                        )
                        lens(10f.dp.toPx() * progress, 14f.dp.toPx() * progress, chromaticAberration = true)
                    },
                    highlight = { Highlight.Default.copy(alpha = 0.6f) },
                    shadow = { Shadow(radius = 4f.dp, alpha = 0.4f) },
                    innerShadow = {
                        val progress = drag.pressProgress
                        InnerShadow(radius = 8f.dp * progress, alpha = progress)
                    },
                    layerBlock = {
                        scaleX = drag.scaleX
                        scaleY = drag.scaleY
                        val velocity = drag.velocity / 10f
                        scaleX /= 1f - (velocity * 0.75f).fastCoerceIn(-0.2f, 0.2f)
                        scaleY *= 1f - (velocity * 0.25f).fastCoerceIn(-0.2f, 0.2f)
                    },
                    onDrawSurface = {
                        val lumNorm = ((luminance() - 0.3f) / 0.5f).coerceIn(0f, 1f)
                        val darken = if (isDark) lerp(0.22f, 0.55f, lumNorm) else lerp(0.06f, 0.14f, lumNorm)
                        drawRect(Color.Black.copy(alpha = darken))
                    },
                )

        GlassTier.BLUR ->
            this
                .graphicsLayer { translationX = offsetX() }
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { CapsuleShape },
                    effects = {
                        colorControls(
                            brightness = 0.05f,
                            contrast = 1f,
                            saturation = 1.4f,
                        )
                        blur(18f.dp.toPx())
                    },
                    layerBlock = {
                        scaleX = drag.scaleX
                        scaleY = drag.scaleY
                        val velocity = drag.velocity / 10f
                        scaleX /= 1f - (velocity * 0.75f).fastCoerceIn(-0.2f, 0.2f)
                        scaleY *= 1f - (velocity * 0.25f).fastCoerceIn(-0.2f, 0.2f)
                    },
                    onDrawSurface = {
                        val lumNorm = ((luminance() - 0.3f) / 0.5f).coerceIn(0f, 1f)
                        val darken = if (isDark) lerp(0.22f, 0.55f, lumNorm) else lerp(0.06f, 0.14f, lumNorm)
                        drawRect(Color.Black.copy(alpha = darken))
                    },
                )

        GlassTier.FROSTED ->
            this
                .graphicsLayer {
                    translationX = offsetX()
                    scaleX = drag.scaleX
                    scaleY = drag.scaleY
                    val velocity = drag.velocity / 10f
                    scaleX /= 1f - (velocity * 0.75f).fastCoerceIn(-0.2f, 0.2f)
                    scaleY *= 1f - (velocity * 0.25f).fastCoerceIn(-0.2f, 0.2f)
                }.clip(CapsuleShape)
                .background(if (isDark) Color.White.copy(alpha = 0.16f) else Color.Black.copy(alpha = 0.09f))
                .border(0.75.dp, frostedEdge(isDark), CapsuleShape)
    }

private fun frostedFill(isDark: Boolean): Color =
    if (isDark) Color(0xFF1C1B1F).copy(alpha = 0.84f) else Color(0xFFF7F2FA).copy(alpha = 0.88f)

private fun frostedEdge(isDark: Boolean): Color =
    if (isDark) Color.White.copy(alpha = 0.20f) else Color.Black.copy(alpha = 0.10f)
