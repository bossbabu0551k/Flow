package io.github.aedev.flow.ui.glass

import androidx.compose.foundation.background
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.backdrops.LayerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.colorControls
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy

/**
 * The backdrop that glass surfaces sample (the page behind them).
 *
 * The surface that uses it MUST be a sibling of the box that carries
 * `Modifier.layerBackdrop(backdrop)`, never a child of it, or the effect feeds back into itself.
 */
@Composable
fun rememberFlowBackdrop(): LayerBackdrop {
    val page = MaterialTheme.colorScheme.background
    return rememberLayerBackdrop {
        drawRect(page)
        drawContent()
    }
}

/**
 * Glass for a surface such as the bottom bar.
 *
 * - Android 13+  : liquid glass (blur + refracting lens + vibrancy), as in SimpMusic.
 * - Android 12/L : real-time backdrop blur.
 * - Android 11-  : frosted, mostly opaque tint (Android has no GPU blur there).
 *
 * Every tier lays a scrim of the page colour over the glass so icons and text stay readable on any
 * content that scrolls behind.
 */
@Composable
fun Modifier.flowGlass(
    backdrop: LayerBackdrop,
    shape: Shape,
): Modifier {
    val scheme = MaterialTheme.colorScheme
    val dark = scheme.background.luminance() < 0.5f
    val scrim = if (dark) Color.Black.copy(alpha = 0.40f) else Color.White.copy(alpha = 0.52f)
    return when (FlowGlass.tier) {
        GlassTier.LIQUID ->
            this.drawBackdrop(
                backdrop = backdrop,
                shape = { shape },
                effects = {
                    vibrancy()
                    colorControls(
                        brightness = 0.05f,
                        contrast = 1f,
                        saturation = 1.4f,
                    )
                    blur(10f.dp.toPx())
                    lens(size.minDimension / 4f, size.minDimension / 2f, false)
                },
                onDrawSurface = { drawScrim(scrim) },
            )

        GlassTier.BLUR ->
            this.drawBackdrop(
                backdrop = backdrop,
                shape = { shape },
                effects = {
                    colorControls(
                        brightness = 0.05f,
                        contrast = 1f,
                        saturation = 1.3f,
                    )
                    blur(16f.dp.toPx())
                },
                onDrawSurface = { drawScrim(scrim) },
            )

        GlassTier.FROSTED -> this.background(scheme.surfaceContainer.copy(alpha = 0.94f), shape)
    }
}

private fun DrawScope.drawScrim(color: Color) {
    drawRect(color)
}
