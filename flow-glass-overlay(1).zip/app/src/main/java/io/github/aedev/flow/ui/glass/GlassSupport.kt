package io.github.aedev.flow.ui.glass

import android.os.Build
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * How much of the glass look this phone can draw.
 *
 * - [LIQUID]  Android 13+  : real backdrop blur plus the refracting "liquid glass" lens.
 * - [BLUR]    Android 12/12L: real-time backdrop blur (RenderEffect), no lens.
 * - [FROSTED] Android 11 and older: Android has no GPU blur API there, so surfaces fall back to a
 *             frosted, semi-opaque tint that keeps text readable.
 */
enum class GlassTier { LIQUID, BLUR, FROSTED }

object FlowGlass {
    val tier: GlassTier =
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> GlassTier.LIQUID
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> GlassTier.BLUR
            else -> GlassTier.FROSTED
        }
}

/**
 * True while the "Ambient" theme style is selected (and the resolved style is not Light).
 * Provided once at the app root by the theme wrapper in ui/startup/ThemeSettings.kt.
 */
val LocalAmbientStyle = staticCompositionLocalOf { false }

/**
 * Status-bar height the root scaffold would normally reserve above a screen. A screen that draws
 * under the status bar (Home) reads it to pad its own header.
 */
val LocalRootTopInset = compositionLocalOf { 0.dp }

/** Extra top padding the feed lists under a glass header must add so content starts below it. */
val LocalFeedTopInset = compositionLocalOf<Dp> { 0.dp }

/** While true, the shared top bar paints no container so the glass/glow behind it shows through. */
val LocalFlowTopBarTransparent = compositionLocalOf { false }
