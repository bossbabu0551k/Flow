package io.github.aedev.flow.ui.glass

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.min
import kotlin.math.roundToInt

private const val RAMP_STEPS = 12

// Blur strength per level, lightest first, and the fraction of the band each level reaches.
// Heavier levels sit on top and stop earlier, so the blur radius is largest at the very top edge
// and steps down smoothly towards the bottom of the band, where the content is sharp again.
private val LEVEL_RADIUS = listOf(5.dp, 14.dp, 30.dp, 52.dp)
private val LEVEL_REACH = floatArrayOf(1.00f, 0.70f, 0.46f, 0.26f)

/**
 * Progressive top-edge blur for a scrolling list (the iOS 26 "scroll edge" look).
 *
 * Content that scrolls up under the header is blurred with a very large radius at the top edge,
 * and the radius shrinks steadily as it moves down, until it is perfectly sharp at the bottom of
 * the band. Apply it to the container that holds the list; draw the header on top of it.
 *
 * [bandHeightPx] is the band height (header height plus a fade zone). [amount] is 0 while the list
 * sits at its start, so nothing is blurred and no extra work is done, and 1 once content has
 * scrolled under the header. Both are read while drawing, so changing them never recomposes.
 *
 * Android 12+ blurs for real with RenderEffect, on the band only. Older Android has no GPU blur,
 * so the band becomes a fade into the page colour.
 */
@Composable
fun Modifier.progressiveTopBlur(
    bandHeightPx: () -> Float,
    amount: () -> Float,
): Modifier {
    val source = rememberGraphicsLayer()
    val levels = List(LEVEL_RADIUS.size) { rememberGraphicsLayer() }
    val density = LocalDensity.current
    val radii = LEVEL_RADIUS.map { with(density) { it.toPx() } }
    val page = MaterialTheme.colorScheme.background
    val canBlur = FlowGlass.tier != GlassTier.FROSTED

    return this.drawWithContent {
        val strength = amount().coerceIn(0f, 1f)
        val band = min(bandHeightPx(), size.height)
        if (strength <= 0.01f || band <= 1f || size.width <= 0f) {
            drawContent()
            return@drawWithContent
        }

        source.record { this@drawWithContent.drawContent() }

        // Sharp content below the band.
        clipRect(top = band) { drawLayer(source) }

        val bandBounds = Rect(0f, 0f, size.width, band)
        val bandSize = Size(size.width, band)

        drawIntoCanvas { canvas ->
            // Sharp content inside the band, erased where the blur takes over.
            canvas.saveLayer(bandBounds, Paint())
            clipRect(top = 0f, bottom = band) { drawLayer(source) }
            drawRect(
                brush = rampBrush(band, strength, LEVEL_REACH[0]),
                size = bandSize,
                blendMode = BlendMode.DstOut,
            )
            canvas.restore()
        }

        if (canBlur) {
            levels.forEachIndexed { i, level ->
                // A heavier level only matters near the top, so it is blurred over that part only.
                val levelHeight = (band * LEVEL_REACH[i]).coerceAtLeast(1f)
                val levelPx = IntSize(size.width.roundToInt(), levelHeight.roundToInt().coerceAtLeast(1))
                level.record(this, layoutDirection, levelPx) { drawLayer(source) }
                level.renderEffect = BlurEffect(radii[i], radii[i], TileMode.Clamp)
                drawIntoCanvas { canvas ->
                    canvas.saveLayer(Rect(0f, 0f, size.width, levelHeight), Paint())
                    drawLayer(level)
                    drawRect(
                        brush = rampBrush(levelHeight, strength, 1f),
                        size = Size(size.width, levelHeight),
                        blendMode = BlendMode.DstIn,
                    )
                    canvas.restore()
                }
            }
        }
        // A veil of the page colour behind the header text: strongest at the top, gone by the
        // bottom of the band. It keeps titles and icons readable over whatever has been blurred.
        drawRect(
            brush = veilBrush(page, band, strength * (if (canBlur) 0.40f else 0.92f)),
            size = bandSize,
        )
    }
}

/** Alpha 1 at the top edge, easing to 0 at [reach] of the band height (and staying 0 below). */
private fun rampBrush(
    band: Float,
    strength: Float,
    reach: Float,
): Brush =
    Brush.verticalGradient(
        colorStops =
            Array(RAMP_STEPS + 2) { i ->
                if (i > RAMP_STEPS) {
                    1f to Color.Black.copy(alpha = 0f)
                } else {
                    val t = i / RAMP_STEPS.toFloat()
                    val eased = t * t * (3f - 2f * t)
                    (t * reach) to Color.Black.copy(alpha = strength * (1f - eased))
                }
            },
        startY = 0f,
        endY = band,
    )

private fun veilBrush(
    color: Color,
    band: Float,
    peak: Float,
): Brush =
    Brush.verticalGradient(
        colorStops =
            Array(RAMP_STEPS + 1) { i ->
                val t = i / RAMP_STEPS.toFloat()
                val eased = t * t * (3f - 2f * t)
                t to color.copy(alpha = peak * (1f - eased))
            },
        startY = 0f,
        endY = band,
    )
