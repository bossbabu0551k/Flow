package io.github.aedev.flow.ui.glass

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import io.github.aedev.flow.player.EnhancedMusicPlayerManager
import io.github.aedev.flow.player.EnhancedPlayerManager
import io.github.aedev.flow.ui.components.shared.rememberMediaPalette
import io.github.aedev.flow.ui.theme.withTone
import kotlin.math.min

private const val GLOW_STEPS = 14
private const val GLOW_PEAK_DARK = 0.50f
private const val GLOW_PEAK_LIGHT = 0.34f
private const val GLOW_TONE_DARK = 42.0
private const val GLOW_TONE_LIGHT = 82.0
private const val GLOW_RADIUS_OF_WIDTH = 1.05f
private const val GLOW_MAX_RADIUS_OF_HEIGHT = 0.46f

/**
 * Colour and strength of the top-left glow, as animated state read only while drawing.
 *
 * Colour: the artwork of the song that is playing; with no music playing, the active theme's
 * primary colour (the wallpaper colour on Material You). Strength drops to zero while a video is
 * playing, because the video's own ambient mode owns the screen then.
 */
@Stable
class TopGlowState internal constructor(
    val color: State<Color>,
    val presence: State<Float>,
    val peak: Float,
)

@Composable
fun rememberTopGlowState(): TopGlowState {
    val track by EnhancedMusicPlayerManager.currentTrack.collectAsStateWithLifecycle()
    val musicState by EnhancedMusicPlayerManager.playerState.collectAsStateWithLifecycle()
    val videoState by EnhancedPlayerManager.getInstance().playerState.collectAsStateWithLifecycle()
    val scheme = MaterialTheme.colorScheme

    val musicActive = track != null && musicState.isPlaying
    val palette = rememberMediaPalette(thumbnailUrl = if (musicActive) track?.thumbnailUrl else null, animated = false)
    val dark = scheme.background.luminance() < 0.5f
    val source = if (musicActive) palette.accent else scheme.primary
    // Hue and saturation come from the artwork or theme; brightness is pinned so the wash can
    // never get bright enough to hurt the contrast of the title and icons it sits under.
    val target = remember(source, dark) { source.withTone(if (dark) GLOW_TONE_DARK else GLOW_TONE_LIGHT) }
    val color = animateColorAsState(target, tween(900), label = "topGlowColor")
    val presence = animateFloatAsState(if (videoState.isPlaying) 0f else 1f, tween(600), label = "topGlowPresence")
    return remember(color, presence, dark) { TopGlowState(color, presence, if (dark) GLOW_PEAK_DARK else GLOW_PEAK_LIGHT) }
}

/**
 * Draws the glow as a soft radial wash that starts in the top-left corner and has faded out well
 * before the middle of the screen. It is shifted up by [scrollPx], so it scrolls away with the list
 * instead of staying pinned. Apply it behind the content (a background layer), never over it.
 */
fun Modifier.topLeftGlow(
    glow: TopGlowState,
    scrollPx: () -> Float,
): Modifier =
    drawBehind {
        val alpha = glow.presence.value
        if (alpha <= 0.002f) return@drawBehind
        val radius = min(size.width * GLOW_RADIUS_OF_WIDTH, size.height * GLOW_MAX_RADIUS_OF_HEIGHT)
        val scroll = scrollPx().coerceAtLeast(0f)
        if (scroll >= radius) return@drawBehind
        val color = glow.color.value
        // Smoothstep easing: flat at both ends, so there is no visible edge where it stops.
        val stops =
            Array(GLOW_STEPS + 1) { i ->
                val t = i / GLOW_STEPS.toFloat()
                val eased = t * t * (3f - 2f * t)
                t to color.copy(alpha = glow.peak * alpha * (1f - eased))
            }
        drawRect(
            brush = Brush.radialGradient(colorStops = stops, center = Offset(0f, -scroll), radius = radius),
            size = Size(size.width, radius - scroll),
        )
    }
