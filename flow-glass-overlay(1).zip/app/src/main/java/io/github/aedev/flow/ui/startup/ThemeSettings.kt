package io.github.aedev.flow.ui.startup

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.ui.text.font.FontFamily
import io.github.aedev.flow.data.local.AppFontPreferences
import io.github.aedev.flow.data.local.LocalDataManager
import io.github.aedev.flow.ui.glass.LocalAmbientStyle
import io.github.aedev.flow.ui.theme.CustomTheme
import io.github.aedev.flow.ui.theme.FlowFontFamily
import io.github.aedev.flow.ui.theme.FlowTheme
import io.github.aedev.flow.ui.theme.ThemeMode
import io.github.aedev.flow.ui.theme.ThemeVariant
import io.github.aedev.flow.ui.theme.resolveFlowThemeSlot
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

/** Every stored theme choice the root theme needs, read as one value so the first frame has all of them. */
@Immutable
data class ThemeSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val themeVariant: ThemeVariant = ThemeVariant.DARK,
    val customTheme: CustomTheme? = null,
    val systemLightThemeMode: ThemeMode = ThemeMode.DARK,
    val systemDarkThemeMode: ThemeMode = ThemeMode.DARK,
    val systemDarkThemeVariant: ThemeVariant = ThemeVariant.DARK,
    val fontFamily: FontFamily = FlowFontFamily,
    val ambientStyle: Boolean = false,
)

fun LocalDataManager.themeSettings(fonts: AppFontPreferences): Flow<ThemeSettings> =
    combine(themeMode, themeVariant, activeCustomTheme, systemLightThemeMode, systemDarkThemeMode) { mode, variant, custom, light, dark ->
        ThemeSettings(mode, variant, custom, light, dark)
    }.combine(systemDarkThemeVariant) { settings, darkVariant -> settings.copy(systemDarkThemeVariant = darkVariant) }
        .combine(fonts.fontFamily) { settings, family -> settings.copy(fontFamily = family) }
        .combine(ambientStyle) { settings, ambient -> settings.copy(ambientStyle = ambient) }

@Composable
fun FlowTheme(
    settings: ThemeSettings,
    content: @Composable () -> Unit,
) {
    // Ambient is a dark style. If the settings would resolve to Light (for example "Follow system"
    // while the phone is in light mode), the same palette is shown in its dark variant instead, so
    // choosing Ambient always has an effect and text stays readable over the video backdrop.
    val slot =
        resolveFlowThemeSlot(
            isSystemDark = isSystemInDarkTheme(),
            themeMode = settings.themeMode,
            themeVariant = settings.themeVariant,
            systemLightThemeMode = settings.systemLightThemeMode,
            systemDarkThemeMode = settings.systemDarkThemeMode,
            systemDarkThemeVariant = settings.systemDarkThemeVariant,
        )
    val forceDark = settings.ambientStyle && slot.variant == ThemeVariant.LIGHT
    CompositionLocalProvider(LocalAmbientStyle provides settings.ambientStyle) {
        FlowTheme(
            themeMode = if (forceDark) slot.mode else settings.themeMode,
            themeVariant = if (forceDark) ThemeVariant.DARK else settings.themeVariant,
            customTheme = settings.customTheme,
            systemLightThemeMode = settings.systemLightThemeMode,
            systemDarkThemeMode = settings.systemDarkThemeMode,
            systemDarkThemeVariant = settings.systemDarkThemeVariant,
            fontFamily = settings.fontFamily,
            content = content,
        )
    }
}
