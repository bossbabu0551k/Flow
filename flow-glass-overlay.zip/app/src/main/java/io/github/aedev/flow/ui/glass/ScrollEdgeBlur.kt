package io.github.aedev.flow.ui.glass

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.min
import kotlin.math.roundToInt

private const val EDGE_STEPS = 12

/**
 * The iOS-26 style "scroll edge" effect for the top of a scrolling list.
 *
 * Content that scrolls toward the top edge gets progressively blurred and fades out, strongest at
 * the very top edge and smoothly transparent towards the bottom of the band. Apply it to the
 * container that holds the list.
 *
 * [intensity] is 0f while the list sits at its start (nothing has scrolled under the edge, so
 * nothing is blurred and nothing extra is drawn) and 1f once it has scrolled; read it from the
 * list state. It is read while drawing, so changing it never recomposes.
 *
 * Android 12+ blurs for real (RenderEffect on the band only). Older Android cannot blur on the GPU,
 * so the band becomes a soft fade into the page colour instead.
 */
@Composable
fun Modifier.scrollEdgeBlur(
    intensity: () -> Float,
    height: Dp = 72.dp,
    blurRadius: Dp = 22.dp,
): Modifier {
    val source = rememberGraphicsLayer()
    val band = rememberGraphicsLayer()
    val density = LocalDensity.current
    val heightPx = with(density) { height.toPx() }
    val radiusPx = with(density) { blurRadius.toPx() }
    val pageColor = MaterialTheme.colorScheme.background
    val canBlur = FlowGlass.tier != GlassTier.FROSTED

    return this.drawWithContent {
        val amount = intensity().coerceIn(0f, 1f)
        if (amount <= 0.01f || size.width <= 0f || size.height <= 0f) {
            drawContent()
            return@drawWithContent
        }

        source.record { this@drawWithContent.drawContent() }
        drawLayer(source)

        val bandHeight = min(heightPx, size.height)
        val bandSize = Size(size.width, bandHeight)
        val fade = fadeBrush(pageColor, bandHeight, amount * (if (canBlur) 0.35f else 0.92f))

        if (canBlur) {
            band.record(this, layoutDirection, IntSize(size.width.roundToInt(), bandHeight.roundToInt())) {
                drawLayer(source)
            }
            band.renderEffect = BlurEffect(radiusPx, radiusPx, TileMode.Clamp)

            drawIntoCanvas { canvas ->
                canvas.saveLayer(Rect(0f, 0f, size.width, bandHeight), Paint())
                drawLayer(band)
                // Keep the blurred copy only where this mask is opaque: full at the top edge, none
                // at the bottom of the band, with a smooth ramp in between.
                drawRect(
                    brush = maskBrush(bandHeight, amount),
                    size = bandSize,
                    blendMode = BlendMode.DstIn,
                )
                canvas.restore()
            }
        }
        drawRect(brush = fade, size = bandSize)
    }
}

private fun maskBrush(
    bandHeight: Float,
    amount: Float,
): Brush =
    Brush.verticalGradient(
        colorStops =
            Array(EDGE_STEPS + 1) { i ->
                val t = i / EDGE_STEPS.toFloat()
                val eased = t * t * (3f - 2f * t)
                t to Color.Black.copy(alpha = amount * (1f - eased))
            },
        startY = 0f,
        endY = bandHeight,
    )

private fun fadeBrush(
    color: Color,
    bandHeight: Float,
    peakAlpha: Float,
): Brush =
    Brush.verticalGradient(
        colorStops =
            Array(EDGE_STEPS + 1) { i ->
                val t = i / EDGE_STEPS.toFloat()
                val eased = t * t * (3f - 2f * t)
                t to color.copy(alpha = peakAlpha * (1f - eased))
            },
        startY = 0f,
        endY = bandHeight,
    )
