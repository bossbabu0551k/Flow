package io.github.aedev.flow.ui.glass

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.luminance
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import io.github.aedev.flow.player.EnhancedMusicPlayerManager
import io.github.aedev.flow.player.EnhancedPlayerManager
import io.github.aedev.flow.ui.components.shared.rememberMediaPalette
import io.github.aedev.flow.ui.theme.withTone

private const val GLOW_HEIGHT_FRACTION = 0.46f
private const val GLOW_STEPS = 14
private const val GLOW_PEAK_DARK = 0.44f
private const val GLOW_PEAK_LIGHT = 0.30f
private const val GLOW_TONE_DARK = 42.0
private const val GLOW_TONE_LIGHT = 82.0

/**
 * A soft colour wash from the very top edge that has faded out before the middle of the screen.
 *
 * Colour: the artwork of the song that is playing; with no music playing, the active theme's
 * primary colour (which is the wallpaper colour for Material You and the chosen palette otherwise).
 * It is hidden while a video is playing, because the video's own ambient mode owns the screen then.
 *
 * It is an overlay that draws no pointer input, so it never blocks touches. The wash is capped at
 * [GLOW_PEAK_DARK] / [GLOW_PEAK_LIGHT] alpha so text and icons under it stay readable.
 */
@Composable
fun FlowTopGlow(
    visible: Boolean,
    modifier: Modifier = Modifier,
) {
    val track by EnhancedMusicPlayerManager.currentTrack.collectAsStateWithLifecycle()
    val musicState by EnhancedMusicPlayerManager.playerState.collectAsStateWithLifecycle()
    val videoState by EnhancedPlayerManager.getInstance().playerState.collectAsStateWithLifecycle()
    val scheme = MaterialTheme.colorScheme

    val musicActive = track != null && musicState.isPlaying
    val palette = rememberMediaPalette(thumbnailUrl = if (musicActive) track?.thumbnailUrl else null, animated = false)
    val dark = scheme.background.luminance() < 0.5f
    val source = if (musicActive) palette.accent else scheme.primary
    // Hue and saturation come from the artwork or theme; the brightness is pinned so the wash can
    // never get bright enough to hurt the contrast of the title and icons it sits under.
    val target = remember(source, dark) { source.withTone(if (dark) GLOW_TONE_DARK else GLOW_TONE_LIGHT) }
    val tint = animateColorAsState(target, tween(900), label = "topGlowTint")

    val show = visible && !videoState.isPlaying
    val presence = animateFloatAsState(if (show) 1f else 0f, tween(600), label = "topGlowPresence")
    val peak = if (dark) GLOW_PEAK_DARK else GLOW_PEAK_LIGHT

    Box(
        modifier =
            modifier.fillMaxSize().drawBehind {
                val a = presence.value
                if (a <= 0.002f) return@drawBehind
                val color = tint.value
                val glowHeight = size.height * GLOW_HEIGHT_FRACTION
                // Smoothstep easing: flat at both ends, so there is no visible edge where it stops.
                val stops =
                    Array(GLOW_STEPS + 1) { i ->
                        val t = i / GLOW_STEPS.toFloat()
                        val eased = t * t * (3f - 2f * t)
                        t to color.copy(alpha = peak * a * (1f - eased))
                    }
                drawRect(
                    brush = Brush.verticalGradient(colorStops = stops, startY = 0f, endY = glowHeight),
                    size = Size(size.width, glowHeight),
                )
            },
    )
}
